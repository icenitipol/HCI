import { getDT } from "./GameUpdate"
//type xy = { x:number, y:number }

// export const xy = (x:number = 0, y:number = 0) => {
//     let xy_obj = {
//       x,y,
//       push: (value:xy) => { 
//         let dt = getDT()
//         xy_obj.x += value.x * dt
//         xy_obj.y += value.y * dt
//         return xy_obj
//       },
//     }
//     return xy_obj
//   }

