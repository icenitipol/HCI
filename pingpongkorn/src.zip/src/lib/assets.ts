import c1 from '../assets/Character/c1.png'
import c2 from '../assets/Character/c2.png'
import c3 from '../assets/Character/c3.png'
import c4 from '../assets/Character/c4.png'
import c5 from '../assets/Character/c5.png'

export const assets = {
    charactors: [c1,c2,c3,c4,c5]
}