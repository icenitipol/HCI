export const firebaseConfig = {
    apiKey: "AIzaSyBOfdZmlKlO0QJkkC1vmhcstUM0iJv7XhE",
    authDomain: "hci-us.firebaseapp.com",
    databaseURL: "https://hci-us-default-rtdb.firebaseio.com",
    projectId: "hci-us",
    storageBucket: "hci-us.appspot.com",
    messagingSenderId: "974465505477",
    appId: "1:974465505477:web:24c3ca3ceaa0a448b0f8ac"
}